#include<iostream>
#include<fstream>
#include<ostream>
#include<string>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<list>
#include <utility> 
#include <algorithm>

#ifndef MAIN_H
#define MAIN_H
using namespace std;

ofstream solution;


#endif



